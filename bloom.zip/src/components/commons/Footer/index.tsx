import React from 'react';
import s from './footer.module.scss';

const Footer = () => {
  return (
    <div className={s.container}>
      <div className={s.wrapper}>footer</div>
    </div>
  );
};

export default Footer;
