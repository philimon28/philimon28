export enum AuthTypeKeys {
  LOGIN = 'LOGIN',
  LOGOUT = 'LOGOUT',
  CLIENT = 'CLIENT',
  FREELANCER = 'FREELANCER',
}
