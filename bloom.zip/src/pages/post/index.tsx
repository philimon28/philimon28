import React from 'react';
import PostJob from 'src/scenes/CreateJobPost';

const PostAJob = () => {
  return <PostJob />;
};

export default PostAJob;
