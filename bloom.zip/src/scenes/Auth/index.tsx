import React from 'react';
import s from './auth.module.scss';

const Auth = () => {
  return (
    <div className={s.container}>
      <div className={s.wrapper}></div>
    </div>
  );
};

export default Auth;
